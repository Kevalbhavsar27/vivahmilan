<?php
	$conn=mysqli_connect("localhost:3307","root","","vivahmilan");
	$a="Vivahmilan";
?>