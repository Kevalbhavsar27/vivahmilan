<?php
        include("connection.php");
        $ID=$_GET['lid'];
        $str="delete from tbl_language where Language_ID =".$ID;
        mysqli_query($conn,$str);
        header('location:language_list.php');
                          
?>