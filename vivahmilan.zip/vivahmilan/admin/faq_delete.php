<?php
        include("connection.php");
        $ID=$_GET['fid'];
        $str="delete from tbl_faq where Faq_ID =".$ID;
        mysqli_query($conn,$str);
        header('location:faq_list.php');
                          
?>